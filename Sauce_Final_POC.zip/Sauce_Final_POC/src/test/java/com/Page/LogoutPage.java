package com.Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LogoutPage {

	WebDriver driver;

	@FindBy(id = "react-burger-menu-btn")
	WebElement clickonmenubutton;

	@FindBy(id = "logout_sidebar_link")
	WebElement getlogouttext;

	@FindBy(id = "logout_sidebar_link")
	WebElement clickonlogoutbutton;

	public LogoutPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	public void clickOnMenuButton() {
		clickonmenubutton.click();

	}

	public void getLogoutText() {

		String getlogouttxt = getlogouttext.getText();

		Assert.assertNotEquals(getlogouttxt, "Login");
	
	}

	public void clickOnLogout() {
		clickonlogoutbutton.click();

	}

}
