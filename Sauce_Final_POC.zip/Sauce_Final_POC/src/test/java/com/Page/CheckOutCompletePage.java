package com.Page;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckOutCompletePage {
	
	WebDriver driver;

	@FindBy(xpath = "//h2[@class=\"complete-header\"]")
	WebElement getcompleteheadermessage;

	@FindBy(xpath = "//div[@class=\"complete-text\"]")
	WebElement getcompletetext;

	@FindBy(xpath = "//span[@class=\"title\"]")
	WebElement getcheckouttitle;

	@FindBy(id = "back-to-products")
	WebElement clickonbackhome;

	public CheckOutCompletePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void getCompleteHeaderMessage() {
		String getheadermessage = getcompleteheadermessage.getText();
		System.out.println(getheadermessage);
	}

	public void getCompleteText() {
		String getcompletetextmessage = getcompletetext.getText();
		System.out.println(getcompletetextmessage);
	}

	public void getCheckoutTitle() {
		String getcheckouttitlemessage = getcheckouttitle.getText();
		System.out.println(getcheckouttitlemessage);

	}

	public void clickOnBackHome() {

		clickonbackhome.click();
	}


}
