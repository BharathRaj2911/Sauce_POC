package com.Page;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CartPage {
	
	WebDriver driver;

	@FindBy(xpath = "//div[@class=\"cart_list\"]")
	WebElement gettextproductsincart;

	@FindBy(id = "remove-sauce-labs-bolt-t-shirt")
	WebElement removetheproductincart;

	@FindBy(id = "continue-shopping")
	WebElement clickoncontinueshopping;

	@FindBy(id = "checkout")
	WebElement clickoncheckout;

	public CartPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	public void getTextProductsInCart() {

		String getproducttext = gettextproductsincart.getText();
		System.out.println(getproducttext);
	}

	public void removeTheProductInCart() {
		removetheproductincart.click();
	}

	
	public void clickOnContinueShopping() {
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		clickoncontinueshopping.click();

	}

	public void clickOnCheckoutButton() {
		clickoncheckout.click();
//		zJavascriptExecutor js3 = (JavascriptExecutor) driver;
//		js3.executeScript("window.scrollBy(0,-400)", "");
}


}
