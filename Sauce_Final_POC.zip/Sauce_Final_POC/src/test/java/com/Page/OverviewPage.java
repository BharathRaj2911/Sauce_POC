package com.Page;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OverviewPage {
	
WebDriver driver;
	
	@FindBy(xpath="//div[@class=\"summary_info_label summary_total_label\"]")
	WebElement gettotalprice;
	
	@FindBy(id="finish")
	WebElement clickonfinish;
	
	
	public OverviewPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
	}
	
	public void getTotalPrice() {
		
		String totalprice = gettotalprice.getText();
		System.out.println(totalprice);
		
	}
	
	public void clickFinish() {
		clickonfinish.click();
	}

}
