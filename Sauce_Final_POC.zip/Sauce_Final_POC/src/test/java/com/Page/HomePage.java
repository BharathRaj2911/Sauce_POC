package com.Page;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class HomePage {

	WebDriver driver;

	@FindBy(id = "react-burger-menu-btn")
	WebElement clickonmenubutton;

	@FindBy(id = "react-burger-cross-btn")
	WebElement clickonclose;

	@FindBy(xpath = "//span[@class='title']")
	WebElement getproducttext;

	@FindBy(xpath = "//select[@class='product_sort_container']")
	WebElement getfilterlist;

	@FindBy(xpath = "//select[@class='product_sort_container']")
	WebElement selectfilterlowtohigh;

	@FindBy(xpath = "//option[text()='Price (low to high)']")
	WebElement getselectedfiltertext;

	@FindBy(id = "add-to-cart-sauce-labs-bolt-t-shirt")
	WebElement clicktshirt;

	@FindBy(id = "add-to-cart-test.allthethings()-t-shirt-(red)")
	WebElement clicktshirtred;

	@FindBy(id = "add-to-cart-sauce-labs-fleece-jacket")
	WebElement clickonjacket;

	@FindBy(xpath = "//a[@class='shopping_cart_link']")
	WebElement clickoncart;

	@FindBy(id = "add-to-cart-sauce-labs-backpack")
	WebElement clickonbackpack;

	public HomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;

	}

	public void clickOnMenuButton() {
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		clickonmenubutton.click();

	}

	public void clickOnClose() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		clickonclose.click();

	}

	public void getProductText() {
		String producttext = getproducttext.getText();
		System.out.println(producttext);
	}

	public void getFilterList() {
		String filterlist = getfilterlist.getText();
		System.out.println(filterlist);

	}

	public void selectFilter() {

		Select selectfilter = new Select(selectfilterlowtohigh);
		selectfilter.selectByVisibleText("Price (low to high)");

	}

	public void getSelectedFilterText() {
		String getfiltertext = getselectedfiltertext.getText();
		System.out.println(getfiltertext);

		Assert.assertEquals(getfiltertext, "Price (low to high)");
	}

	public void clickTShirt() {
		clicktshirt.click();
	}

	public void clickTShirtRed() {
		clicktshirtred.click();
	}

	public void clickOnJacket() {
		clickonjacket.click();
	}

	public void clickOnCart() {
		clickoncart.click();
	}

	public void clickOnBackpack() {
		clickonbackpack.click();
	}
}
