package com.Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginPage {
	
	WebDriver driver;
	
	@FindBy(xpath = "//div[text()='Swag Labs']")
	WebElement getpagetitle;

	@FindBy(id = "login_credentials")
	WebElement getusername;

	@FindBy(xpath = "//div[@class=\"login_password\"]")
	WebElement getpassword;

	@FindBy(id = "user-name")
	WebElement enterusername;

	@FindBy(id = "password")
	WebElement enterpassword;

	@FindBy(id = "login-button")
	WebElement clicklogin;

	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
	
	public void getPageTitle() {
		String pagetitle = getpagetitle.getText();
		System.out.println(pagetitle);
		Assert.assertEquals(pagetitle, "Swag Labs");

	}
	
	public void getUsername() {
		String username = getusername.getText();
		System.out.println(username);

	}

	public void getPassword() {
		String password = getpassword.getText();
		System.out.println(password);

	}

	public void enterUsername(String username) {
		enterusername.clear();
		enterusername.sendKeys(username);
	}

	public void enterPassword(String password) {
		enterpassword.clear();
		enterpassword.sendKeys(password);

	}

	public void clickLogin() {
		clicklogin.click();


	}
}
