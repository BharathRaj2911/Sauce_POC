package com.Page;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class YourInformationPage {
	
	WebDriver driver;

	@FindBy(id = "first-name")
	WebElement enterfirstname;

	@FindBy(id = "last-name")
	WebElement enterlastname;

	@FindBy(id = "postal-code")
	WebElement enterpincode;

	@FindBy(id = "continue")
	WebElement clickoncontinue;

	public YourInformationPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	public void enterFirstName() {
		enterfirstname.sendKeys("Bharath Raj");
	}

	public void enterLastname() {
		enterlastname.sendKeys("C");
	}

	public void enterPincode() {
		enterpincode.sendKeys("631205");
	
	}

	public void clickOnContinue() {
		clickoncontinue.click();
//		JavascriptExecutor js4 = (JavascriptExecutor) driver;
//		js4.executeScript("window.scrollBy(0,400)", "");
	}



}
