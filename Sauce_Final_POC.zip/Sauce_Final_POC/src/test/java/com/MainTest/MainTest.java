package com.MainTest;

import org.testng.annotations.Test;

import com.Page.HomePage;
import com.Page.LoginPage;
import com.Page.CartPage;
import com.Page.YourInformationPage;
import com.Page.OverviewPage;
import com.Page.CheckOutCompletePage;
import com.Page.LogoutPage;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class MainTest {
	
	WebDriver driver;
	
	LoginPage login;
	HomePage home;
	CartPage cart;
	YourInformationPage yourinformation;
	OverviewPage overview;
	CheckOutCompletePage checkoutcomplete;
	LogoutPage logout;
	
	@BeforeClass
	public void beforeclass() {
		driver = new ChromeDriver();
		  driver.get("https://www.saucedemo.com/");
		  driver.manage().window().maximize();
	}
	@BeforeMethod
	public void beforeMethod() {
		login = new LoginPage(driver);
		home = new HomePage(driver);
		cart = new CartPage(driver);
		yourinformation = new YourInformationPage(driver);
		overview = new OverviewPage(driver);
		checkoutcomplete = new CheckOutCompletePage(driver);
		logout = new LogoutPage(driver);
		
	}
	
  @Test(dataProvider = "create")
  public void f(String username, String password) {
	  
	  
	  
	  login.getPageTitle();
	  login.getUsername();
	  login.getPassword();
	  login.enterUsername(username);
	  login.enterPassword(password);
	  login.clickLogin();
		

	  home.clickOnMenuButton();
	  home.clickOnClose();
	  home.getProductText();
	  home.getFilterList();
	  home.selectFilter();
	  home.getSelectedFilterText();
	  home.clickTShirt();
	  home.clickTShirtRed();
	  home.clickOnJacket();
	  home.clickOnCart();
	  
	  cart.getTextProductsInCart();
	  cart.removeTheProductInCart();
	  cart.clickOnContinueShopping();
	  home.clickOnBackpack();
	  home.clickOnCart();
	  cart.getTextProductsInCart();
	  cart.clickOnCheckoutButton();
	  
	  yourinformation.enterFirstName();
	  yourinformation.enterLastname();
	  yourinformation.enterPincode();
	  yourinformation.clickOnContinue();
	  
	  overview.getTotalPrice();
	  overview.clickFinish();
	  
	  checkoutcomplete.getCompleteHeaderMessage();
	  checkoutcomplete.getCompleteText();
	  checkoutcomplete.getCheckoutTitle();
	  checkoutcomplete.clickOnBackHome();
	  
	  logout.clickOnMenuButton();
	  logout.getLogoutText();
	  logout.clickOnLogout();
	  	  
  }
  
   @AfterMethod
  public void afterMethod() {
	   
	   System.out.println("After Method");
	  
  }
  @AfterClass
  public void afterClass() {
	  
	  driver.quit();
	  
  }


	@DataProvider(name = "create")
	public Object[][] dataSet1() {

		return new Object[][] { 	{"", ""},
									{ "standard_user", "" },
									{ "user", "secret_sauce" },
									{ "standard_user", "secret_sauce" }			
								
	};
	}
}
